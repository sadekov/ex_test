var searchData=
[
  ['reg_27',['reg',['../classMB_1_1ModbusCell.html#a07ff3991875f54c85affdc07e4c26fbb',1,'MB::ModbusCell::reg()'],['../classMB_1_1ModbusCell.html#a783e3b1e2e0ee1c819e77f8eda22ef8a',1,'MB::ModbusCell::reg() const']]]
];
