var searchData=
[
  ['connection_34',['Connection',['../classMB_1_1TCP_1_1Connection.html',1,'MB::TCP::Connection'],['../classMB_1_1Serial_1_1Connection.html',1,'MB::Serial::Connection']]]
];
