var searchData=
[
  ['calculatecrc_43',['calculateCRC',['../namespaceMB_1_1utils.html#aa419ed339bbdacd4108fb5cc1cd14539',1,'MB::utils::calculateCRC(const uint8_t *buff, size_t len)'],['../namespaceMB_1_1utils.html#a102e7bc4008a2658a5db76a9b70bec97',1,'MB::utils::calculateCRC(const std::vector&lt; uint8_t &gt; &amp;buffer)']]],
  ['coil_44',['coil',['../classMB_1_1ModbusCell.html#a0ef75aec736bfb8f7c21599e4e92c6f9',1,'MB::ModbusCell::coil()'],['../classMB_1_1ModbusCell.html#a71a01fcbe23e409bea1f10e926d4d327',1,'MB::ModbusCell::coil() const']]]
];
