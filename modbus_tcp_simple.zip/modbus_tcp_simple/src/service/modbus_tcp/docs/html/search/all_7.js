var searchData=
[
  ['send_28',['send',['../classMB_1_1Serial_1_1Connection.html#a76060ddfbeeb28ad0aa1b35b1c4e3b20',1,'MB::Serial::Connection']]],
  ['server_29',['Server',['../classMB_1_1TCP_1_1Server.html',1,'MB::TCP']]],
  ['setslaveid_30',['setSlaveID',['../classMB_1_1ModbusException.html#a344445f1b157f5e5d66946cd893c72fd',1,'MB::ModbusException']]]
];
