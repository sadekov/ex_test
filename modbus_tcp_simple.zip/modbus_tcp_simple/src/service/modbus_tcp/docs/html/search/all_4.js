var searchData=
[
  ['initcoil_9',['initCoil',['../classMB_1_1ModbusCell.html#aa7aa19c9be4c990fc16fcde1c027e485',1,'MB::ModbusCell']]],
  ['initreg_10',['initReg',['../classMB_1_1ModbusCell.html#a890610419b58a1ec8f7e5cffa6a69d72',1,'MB::ModbusCell']]],
  ['iscoil_11',['isCoil',['../classMB_1_1ModbusCell.html#a282399413ae7f24830680bbd46c8757b',1,'MB::ModbusCell']]],
  ['isreg_12',['isReg',['../classMB_1_1ModbusCell.html#a517c883a6008a6df97aeed57fdbb9126',1,'MB::ModbusCell']]],
  ['isslavevalid_13',['isSlaveValid',['../classMB_1_1ModbusException.html#a2d93520088d9adac402b4558a7441d80',1,'MB::ModbusException']]],
  ['isstandarderrorcode_14',['isStandardErrorCode',['../namespaceMB_1_1utils.html#a7aa22230ea192f06612fbc809fca2335',1,'MB::utils']]]
];
