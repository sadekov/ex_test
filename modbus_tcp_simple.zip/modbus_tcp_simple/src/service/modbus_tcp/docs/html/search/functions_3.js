var searchData=
[
  ['geterrorcode_49',['getErrorCode',['../classMB_1_1ModbusException.html#a99b4583ae15c2a13530e3751e9ad2737',1,'MB::ModbusException']]]
];
